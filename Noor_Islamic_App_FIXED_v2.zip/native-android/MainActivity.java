package com.ahmedbadr.noor;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private static final int REQ_LOCATION = 502;
    private static final int REQ_NOTIF = 501;
    private LocationManager locationManager;
    private LocationListener locationListener;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getBridge().getWebView().addJavascriptInterface(new NoorBridge(this), "AndroidNoor");
    }

    private void requestNativeLocation() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (locationManager == null) { sendLocationError("location_manager"); return; }
        try {
            Location last = null;
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (last != null && System.currentTimeMillis() - last.getTime() < 24L * 60L * 60L * 1000L) {
                sendLocation(last);
                return;
            }
            locationListener = new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    sendLocation(location);
                    try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
                }
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
            };
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000L, 0f, locationListener);
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locationListener);
            getBridge().getWebView().postDelayed(() -> {
                try { if (locationListener != null) locationManager.removeUpdates(locationListener); } catch (Exception ignored) {}
                sendLocationError("timeout");
            }, 20000L);
        } catch (SecurityException e) { sendLocationError("permission"); }
    }

    private void sendLocation(Location l) {
        String js = "window.__nativeLocation(" + l.getLatitude() + "," + l.getLongitude() + "," + l.getAccuracy() + ");";
        getBridge().getWebView().post(() -> getBridge().getWebView().evaluateJavascript(js, null));
    }
    private void sendLocationError(String code) {
        getBridge().getWebView().post(() -> getBridge().getWebView().evaluateJavascript("window.__nativeLocationError('" + code + "')", null));
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = false;
            for (int r : grantResults) if (r == PackageManager.PERMISSION_GRANTED) { granted = true; break; }
            if (granted) requestNativeLocation(); else sendLocationError("permission");
        }
    }

    static class NoorBridge {
        final MainActivity a;
        NoorBridge(MainActivity x){a=x;}
        @JavascriptInterface public void requestLocation(){ a.requestNativeLocation(); }
        @JavascriptInterface public void enableAdhan(){
            a.getSharedPreferences("noor_adhan",MODE_PRIVATE).edit().putBoolean("enabled",true).apply();
            if(Build.VERSION.SDK_INT>=33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);
            if(Build.VERSION.SDK_INT>=31){
                AlarmManager am=(AlarmManager)a.getSystemService(ALARM_SERVICE);
                if(!am.canScheduleExactAlarms()){
                    try{a.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+a.getPackageName())));}catch(Exception ignored){}
                }
            }
        }
        @JavascriptInterface public void disableAdhan(){
            a.getSharedPreferences("noor_adhan",MODE_PRIVATE).edit().putBoolean("enabled",false).apply();
            AlarmManager am=(AlarmManager)a.getSystemService(ALARM_SERVICE);
            for(int i=0;i<10;i++) cancel(a,am,i);
        }
        @JavascriptInterface public void schedulePrayer(int id,String prayer,long when,String url){
            a.getSharedPreferences("noor_adhan",MODE_PRIVATE).edit().putLong("t"+id,when).putString("p"+id,prayer).putString("u"+id,url).apply();
            BootReceiver.schedule(a,id,when,prayer,url);
        }
        @JavascriptInterface public void playNow(String prayer,String url){
            Intent i=new Intent(a,AdhanService.class).putExtra("prayer",prayer).putExtra("url",url);
            if(Build.VERSION.SDK_INT>=26)a.startForegroundService(i);else a.startService(i);
        }
        static void cancel(Context c,AlarmManager am,int id){
            Intent i=new Intent(c,AdhanReceiver.class);
            PendingIntent pi=PendingIntent.getBroadcast(c,7000+id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);pi.cancel();
        }
    }
}
