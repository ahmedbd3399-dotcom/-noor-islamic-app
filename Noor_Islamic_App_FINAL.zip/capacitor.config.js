const config={appId:"com.ahmedbadr.noor",appName:"نُور",webDir:"."}; module.exports=config;
