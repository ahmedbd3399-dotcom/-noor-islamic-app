const config={appId:'com.ahmedbadr.noor',appName:'نُور',webDir:'.',bundledWebRuntime:false};module.exports=config;
