const A='https://api.aladhan.com/v1', Q='https://api.alquran.cloud/v1', CDN='https://cdn.islamic.network';
const surahs=['الفاتحة','البقرة','آل عمران','النساء','المائدة','الأنعام','الأعراف','الأنفال','التوبة','يونس','هود','يوسف','الرعد','إبراهيم','الحجر','النحل','الإسراء','الكهف','مريم','طه','الأنبياء','الحج','المؤمنون','النور','الفرقان','الشعراء','النمل','القصص','العنكبوت','الروم','لقمان','السجدة','الأحزاب','سبأ','فاطر','يس','الصافات','ص','الزمر','غافر','فصلت','الشورى','الزخرف','الدخان','الجاثية','الأحقاف','محمد','الفتح','الحجرات','ق','الذاريات','الطور','النجم','القمر','الرحمن','الواقعة','الحديد','المجادلة','الحشر','الممتحنة','الصف','الجمعة','المنافقون','التغابن','الطلاق','التحريم','الملك','القلم','الحاقة','المعارج','نوح','الجن','المزمل','المدثر','القيامة','الإنسان','المرسلات','النبأ','النازعات','عبس','التكوير','الانفطار','المطففين','الانشقاق','البروج','الطارق','الأعلى','الغاشية','الفجر','البلد','الشمس','الليل','الضحى','الشرح','التين','العلق','القدر','البينة','الزلزلة','العاديات','القارعة','التكاثر','العصر','الهمزة','الفيل','قريش','الماعون','الكوثر','الكافرون','النصر','المسد','الإخلاص','الفلق','الناس'];
const RECITERS=[["مشاري العفاسي","https://server8.mp3quran.net/afs/"],["محمود خليل الحصري","https://server13.mp3quran.net/husr/"],["محمد صديق المنشاوي","https://server10.mp3quran.net/minsh/"],["مصطفى إسماعيل","https://server8.mp3quran.net/mustafa/"],["ماهر المعيقلي","https://server12.mp3quran.net/maher/"],["محمد أيوب","https://server8.mp3quran.net/ayyub/"],["محمد جبريل","https://server8.mp3quran.net/jbrl/"],["محمد اللحيدان","https://server8.mp3quran.net/lhdan/"],["محمد المحيسني","https://server11.mp3quran.net/mhsny/"],["محمد الطبلاوي","https://server12.mp3quran.net/tblawi/"],["خالد الجليل","https://server10.mp3quran.net/jleel/"],["أحمد النفيس","https://server16.mp3quran.net/nufais/Rewayat-Hafs-A-n-Assem/"],["إسلام صبحي","https://server14.mp3quran.net/islam/Rewayat-Hafs-A-n-Assem/"],["بدر التركي","https://server10.mp3quran.net/bader/Rewayat-Hafs-A-n-Assem/"],["أحمد خليل شاهين","https://server16.mp3quran.net/shaheen/Rewayat-Hafs-A-n-Assem/"],["سعد المقرن","https://server16.mp3quran.net/saad/Rewayat-Hafs-A-n-Assem/"],["ناصر الماجد","https://server14.mp3quran.net/nasser_almajed/"],["ناصر العصفور","https://server14.mp3quran.net/alosfor/"],["منصور السالمي","https://server14.mp3quran.net/mansor/"],["عبدالله الخلف","https://server14.mp3quran.net/khalf/"],["محمد البخيت","https://server14.mp3quran.net/bukheet/"],["داود حمزة","https://server9.mp3quran.net/hamza/"],["عبدالرحمن الماجد","https://server10.mp3quran.net/a_majed/"],["عبدالله كامل","https://server16.mp3quran.net/kamel/Rewayat-Hafs-A-n-Assem/"],["أحمد عامر","https://server10.mp3quran.net/Aamer/"],["أحمد الطرابلسي","https://server10.mp3quran.net/trabulsi/"],["عبدالله الكندري","https://server10.mp3quran.net/Abdullahk/"],["محمد عثمان خان","https://server6.mp3quran.net/khan/"],["محمد العالم الدوكالي","https://server7.mp3quran.net/dokali/"],["خالد القحطاني","https://server10.mp3quran.net/qht/"],["الفاتح محمد الزبير","https://server6.mp3quran.net/fateh/"],["رامي الدعيس","https://server6.mp3quran.net/rami/"],["عبدالرحمن العوسي","https://server6.mp3quran.net/aloosi/"],["خالد الغامدي","https://server6.mp3quran.net/ghamdi/"],["محمد خليل القارئ","https://server8.mp3quran.net/m_qari/"],["إبراهيم الجرمي","https://server11.mp3quran.net/jormy/"],["محمود الرفاعي","https://server11.mp3quran.net/mrifai/"],["حاتم فريد الواعر","https://server11.mp3quran.net/hatem/"],["موسى بلال","https://server11.mp3quran.net/bilal/"],["عادل الكلباني","https://server8.mp3quran.net/a_klb/"],["إبراهيم الدوسري","https://server10.mp3quran.net/ibrahim_dosri/Rewayat-Hafs-A-n-Assem/"],["محمد رشاد الشريف","https://server10.mp3quran.net/rashad/"],["معيض الحارثي","https://server8.mp3quran.net/harthi/"],["توفيق الصايغ","https://server6.mp3quran.net/twfeeq/"],["جمال شاكر عبدالله","https://server6.mp3quran.net/jamal/"],["جمعان العصيمي","https://server6.mp3quran.net/jaman/"],["ماجد الزامل","https://server9.mp3quran.net/zaml/"],["القارئ ياسين","https://server11.mp3quran.net/qari/"],["ماهر شخاشيرو","https://server10.mp3quran.net/shaksh/"],["الزين محمد أحمد","https://server9.mp3quran.net/alzain/"],["إدريس أبكر","https://server6.mp3quran.net/abkr/"],["مصطفى اللاهوني","https://server6.mp3quran.net/lahoni/"],["مصطفى رعد العزاوي","https://server8.mp3quran.net/ra3ad/"],["محمد صالح عالم شاه","https://server12.mp3quran.net/shah/"],["محمد عبدالكريم","https://server12.mp3quran.net/m_krm/"],["عبدالله بن عون","https://server16.mp3quran.net/a_binaoun/"],["بندر بليلة","https://server6.mp3quran.net/balilah/"],["عبدالله الموسى","https://server14.mp3quran.net/mousa/Rewayat-Hafs-A-n-Assem/"],["طارق عبدالغني دعوب","https://server10.mp3quran.net/tareq/"],["سلمان العتيبي","https://server11.mp3quran.net/salman/"],["محمد رفعت","https://server14.mp3quran.net/refat/"],["أحمد الحذيفي","https://server8.mp3quran.net/ahmad_huth/"],["عبدالرحمن السويّد","https://server16.mp3quran.net/a_swaiyd/Rewayat-Hafs-A-n-Assem/"],["يوسف الدغوش","https://server7.mp3quran.net/dgsh/"],["هيثم الجدعاني","https://server16.mp3quran.net/hitham/Rewayat-Hafs-A-n-Assem/"],["أحمد السويلم","https://server14.mp3quran.net/swlim/Rewayat-Hafs-A-n-Assem/"],["عمر الدريويز","https://server16.mp3quran.net/darweez/Rewayat-Hafs-A-n-Assem/"],["بدر التركي","https://server10.mp3quran.net/bader/Rewayat-Hafs-A-n-Assem/"],["عثمان الأنصاري","https://server11.mp3quran.net/Othmn/"],["رعد محمد الكردي","https://server6.mp3quran.net/kurdi/"],["هزاع البلوشي","https://server11.mp3quran.net/hazza/"]];
const reciters=RECITERS;
const adhans=[['مشاري العفاسي','https://cdn.aladhan.com/audio/adhans/a9.mp3'],['أحمد النفيس','https://cdn.aladhan.com/audio/adhans/a1.mp3'],['مصطفى أوزجان','https://cdn.aladhan.com/audio/adhans/a2.mp3'],['مؤذن دبي','https://cdn.aladhan.com/audio/adhans/a4.mp3'],['منصور الزهراني','https://cdn.aladhan.com/audio/adhans/a11-mansour-al-zahrani.mp3'],['أذان دبي — نسخة أخرى','https://cdn.aladhan.com/audio/adhans/a7.mp3'],['أذان هادئ','https://cdn.aladhan.com/audio/adhans/a3.mp3']];
const prayers=[['الفجر','Fajr','🌅'],['الشروق','Sunrise','☀️'],['الظهر','Dhuhr','☀️'],['العصر','Asr','🌤️'],['المغرب','Maghrib','🌇'],['العشاء','Isha','🌙']];
const adhkar=[['أذكار الصباح','أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',1,'sabah'],['أذكار المساء','أمسينا وأمسى الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',1,'masaa'],['أذكار بعد الصلاة','أستغفر الله، أستغفر الله، أستغفر الله. اللهم أنت السلام ومنك السلام تباركت يا ذا الجلال والإكرام.',3,'aam'],['التسبيح والتحميد والتكبير','سبحان الله، والحمد لله، والله أكبر.',33,'aam'],['التهليل','لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',100,'aam'],['الصلاة على النبي ﷺ','اللهم صل وسلم وبارك على نبينا محمد ﷺ.',10,'aam'],['سيد الاستغفار','اللهم أنت ربي لا إله إلا أنت، خلقتني وأنا عبدك، وأنا على عهدك ووعدك ما استطعت، أعوذ بك من شر ما صنعت، أبوء لك بنعمتك علي وأبوء بذنبي فاغفر لي، فإنه لا يغفر الذنوب إلا أنت.',1,'sabah'],['أذكار النوم','باسمك اللهم أموت وأحيا.',1,'masaa'],['عند الاستيقاظ','الحمد لله الذي أحيانا بعدما أماتنا وإليه النشور.',1,'sabah'],['دخول المنزل','اللهم إني أسألك خير المولج وخير المخرج، بسم الله ولجنا وبسم الله خرجنا وعلى الله ربنا توكلنا.',1,'aam'],['الخروج من المنزل','بسم الله، توكلت على الله، ولا حول ولا قوة إلا بالله.',1,'aam'],['دخول المسجد','اللهم افتح لي أبواب رحمتك.',1,'aam'],['الخروج من المسجد','اللهم إني أسألك من فضلك.',1,'aam'],['قبل الطعام','بسم الله.',1,'aam'],['بعد الطعام','الحمد لله الذي أطعمني هذا ورزقنيه من غير حول مني ولا قوة.',1,'aam'],['دعاء الكرب','لا إله إلا الله العظيم الحليم، لا إله إلا الله رب العرش العظيم، لا إله إلا الله رب السماوات ورب الأرض ورب العرش الكريم.',1,'aam'],['دعاء الهم والحزن','اللهم إني أعوذ بك من الهم والحزن، وأعوذ بك من العجز والكسل، وأعوذ بك من الجبن والبخل، وأعوذ بك من غلبة الدين وقهر الرجال.',1,'aam'],['دعاء الهداية','اللهم اهدني وسددني.',1,'aam'],['دعاء الوالدين','رب ارحمهما كما ربياني صغيرًا.',1,'aam'],['دعاء السفر','سبحان الذي سخر لنا هذا وما كنا له مقرنين وإنا إلى ربنا لمنقلبون.',1,'aam'],['الاستعاذة','أعوذ بكلمات الله التامات من شر ما خلق.',3,'aam'],['الاستغفار','أستغفر الله وأتوب إليه.',100,'aam']];
const books=[
['الرحيق المختوم','المباركفوري','السيرة النبوية','عرض موجز لسيرة النبي ﷺ من المولد إلى الوفاة والغزوات والدروس المستفادة.'],
['السيرة النبوية لابن هشام','ابن هشام','السيرة النبوية','من أشهر مصادر السيرة النبوية، مرتب في أحداث حياة النبي ﷺ وأخبار الدعوة.'],
['زاد المعاد في هدي خير العباد','ابن القيم','السيرة والهدي','في هدي النبي ﷺ في العبادة والمعاملة والسفر والجهاد وغيرها.'],
['الشمائل المحمدية','الترمذي','السيرة والشمائل','وصف شمائل النبي ﷺ وأخلاقه وصفاته وهديه.'],
['فقه السيرة النبوية','محمد الغزالي','السيرة والدروس','قراءة تربوية في أحداث السيرة وما فيها من دروس وعبر.'],
['مختصر سيرة الرسول ﷺ','محمد بن عبد الوهاب','السيرة النبوية','مختصر تعليمي لأبرز أحداث السيرة النبوية.'],
['رياض الصالحين','النووي','حديث وآداب','أحاديث مختارة في العبادات والأخلاق والآداب والمعاملات.'],
['الأربعون النووية','النووي','حديث','أحاديث جامعة في أصول الدين والعبادة والأخلاق.'],
['صحيح البخاري','الإمام البخاري','حديث','من أشهر كتب الحديث، مرتب على أبواب العلم والعبادات والمعاملات وغيرها.'],
['صحيح مسلم','الإمام مسلم','حديث','من دواوين السنة المشهورة، مرتب على كتب وأبواب متعددة.'],
['سنن أبي داود','أبو داود','حديث وفقه','من كتب السنن، وفيه أحاديث كثيرة تتعلق بأبواب الأحكام.'],
['جامع الترمذي','الترمذي','حديث وفقه','يجمع الحديث مع الإشارة إلى بعض درجاته وأقوال أهل العلم.'],
['سنن النسائي','النسائي','حديث وفقه','كتاب من كتب السنن المعتمدة في الحديث.'],
['سنن ابن ماجه','ابن ماجه','حديث','من كتب السنن المشهورة في أبواب الحديث والأحكام.'],
['تفسير ابن كثير','ابن كثير','تفسير','تفسير للقرآن بالمأثور مع العناية بالحديث وأقوال السلف.'],
['تفسير السعدي','عبد الرحمن السعدي','تفسير','تفسير ميسر واضح العبارة مناسب للقراءة اليومية والتدبر.'],
['تفسير الطبري','الطبري','تفسير','من أقدم وأوسع كتب التفسير بالمأثور واللغة وأقوال العلماء.'],
['تفسير البغوي','البغوي','تفسير','تفسير مختصر نسبيًا يجمع بين الرواية والشرح.'],
['تفسير الجلالين','المحلي والسيوطي','تفسير','تفسير مختصر للآيات بعبارات موجزة.'],
['مختصر تفسير ابن كثير','محمد نسيب الرفاعي','تفسير','اختصار لمادة تفسير ابن كثير في صورة أسهل للمطالعة.'],
['الأذكار','النووي','أذكار','كتاب جامع للأذكار والأدعية في أحوال اليوم والليلة والعبادات.'],
['حصن المسلم','سعيد القحطاني','أذكار','مجموعة عملية من الأذكار والأدعية المشهورة في حياة المسلم اليومية.'],
['الوابل الصيب','ابن القيم','ذكر وتزكية','كتاب في فضل الذكر وآثاره على القلب والعمل.'],
['مدارج السالكين','ابن القيم','تزكية','رحلة في منازل السائرين وأعمال القلوب والتزكية.'],
['الداء والدواء','ابن القيم','تزكية','حديث عن أمراض القلوب وأسبابها وطرق علاجها الشرعي والتربوي.'],
['مختصر منهاج القاصدين','ابن قدامة المقدسي','تزكية وآداب','مختصر في تهذيب النفس والعبادات والأخلاق.'],
['بلوغ المرام','ابن حجر العسقلاني','حديث وفقه','أحاديث أحكام مرتبة على أبواب الفقه.'],
['عمدة الأحكام','عبد الغني المقدسي','حديث وفقه','أحاديث أحكام مختارة من الصحيحين.'],
['الأدب المفرد','الإمام البخاري','آداب وأخلاق','آثار وأحاديث في بر الوالدين وصلة الرحم وحسن الخلق وآداب التعامل.'],
['خلق المسلم','محمد الغزالي','أخلاق','كتاب تربوي عن بناء الأخلاق في حياة المسلم.'],
['منهاج المسلم','أبو بكر الجزائري','فقه وآداب','كتاب شامل في العقيدة والعبادة والأخلاق والمعاملات بصورة تعليمية.'],
['الرحيق المختوم للأطفال','مختارات تعليمية','سيرة للأطفال','قسم مبسط مناسب للصغار للتعرف على أحداث السيرة.'],
['قصص الأنبياء','ابن كثير','قصص الأنبياء','جمع لأخبار وقصص عدد من الأنبياء مع الاستفادة من مصادر التفسير والحديث.'],
['قصص الصحابة','مختارات موثقة','السيرة والتاريخ','بطاقات وقصص مختارة من حياة الصحابة رضي الله عنهم.'],
['نساء حول الرسول ﷺ','مختارات','السيرة','مواقف من حياة أمهات المؤمنين والصحابيات ودروس تربوية منها.'],
['فقه العبادات للمبتدئ','مادة تعليمية','فقه','مدخل مبسط لفهم الطهارة والصلاة والصيام والزكاة مع التنبيه للرجوع لأهل العلم.'],
['آداب طالب العلم','مختارات من كتب العلماء','علم وآداب','مجموعة موضوعات عملية في طلب العلم والإخلاص والأدب والصبر.'],
['الرعاية القلبية','مادة تربوية','تزكية','برنامج قراءة عن مراقبة القلب والإخلاص والمحاسبة وحسن العمل.']
];
const namesAllah=['الرَّحْمَن','الرَّحِيم','الْمَلِك','الْقُدُّوس','السَّلَام','الْمُؤْمِن','الْمُهَيْمِن','الْعَزِيز','الْجَبَّار','الْمُتَكَبِّر','الْخَالِق','الْبَارِئ','الْمُصَوِّر','الْغَفَّار','الْقَهَّار','الْوَهَّاب','الرَّزَّاق','الْفَتَّاح','الْعَلِيم','السَّمِيع','الْبَصِير','الْحَكَم','الْعَدْل','اللَّطِيف','الْخَبِير','الْحَلِيم','الْعَظِيم','الْغَفُور','الشَّكُور','الْعَلِيُّ','الْكَبِير','الْحَفِيظ','الْمُقِيت','الْحسِيب','الْجَلِيل','الْكَرِيم','الرَّقِيب','الْمُجِيب','الْوَاسِع','الْحَكِيم','الْوَدُود','الْمَجِيد','الْبَاعِث','الشَّهِيد','الْحَق','الْوَكِيل','الْقَوِيُّ','الْمَتِين','الْوَلِيُّ','الْحَمِيد','الْمُحْصِي','الْمُبْدِئ','الْمُعِيد','الْمُحْيِي','الْمُمِيت','الْحَيُّ','الْقَيُّوم','الْوَاجِد','الْمَاجِد','الْوَاحِد','الْأَحَد','الصَّمَد','الْقَادِر','الْمُقْتَدِر','الْمُقَدِّم','الْمُؤَخِّر','الْأَوَّل','الْآخِر','الظَّاهِر','الْبَاطِن','الْوَالِي','الْمُتَعَالِي','الْبَرُّ','التَّوَّاب','الْمُنْتَقِم','الْعَفُوُّ','الرَّؤُوف','مَالِكُ الْمُلْك','ذُو الْجَلَالِ وَالْإِكْرَام','الْمُقْسِط','الْجَامِع','الْغَنِيُّ','الْمُغْنِي','الْمَانِع','الضَّار','النَّافِع','النُّور','الْهَادِي','الْبَدِيع','الْبَاقِي','الْوَارِث','الرَّشِيد','الصَّبُور'];
let view=document.getElementById('view'), current='home', prayersData=null, coords=null, audio=null, currentSurah=null;
let state=JSON.parse(localStorage.noorState||'{}');
state.reciter ||= RECITERS[0][1]; state.bookmarks ||= []; state.progress ||= {}; state.plan ||= {}; state.adhan = state.adhan!==false; state.adhanVoice ||= adhans[0][1]; state.method ||= 5; state.location ||= null; localStorage.noorState=JSON.stringify(state);
const save=()=>{localStorage.noorState=JSON.stringify(state)};
function nav(p){current=p; render(); window.scrollTo({top:0,behavior:'smooth'})}
function render(){document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===current)); view.innerHTML=`<section class="page">${({home, quran, azkar:azkarPage, prayer:prayerPage, more}[current]||home)()}</section>`; if(current==='home') homeAfter(); if(current==='prayer') loadPrayer('prayerList'); if(current==='quran') filterSurahs('')}
function home(){return `<div class="hero"><div class="heroTop"><span class="pill">بسم الله الرحمن الرحيم</span><button class="pill locationPill" id="place" onclick="requestLocation()">📍 تحديد موقعي</button></div><h1>السلام عليكم ورحمة الله وبركاته 🌿</h1><p>نُور — رفيقك للقرآن والصلاة والذكر.</p><div class="next"><span>الصلاة القادمة</span><strong id="nextName">جاري الحساب...</strong><b id="nextTime">--:--</b><small id="countdown">--</small></div></div><div class="stats"><div><b id="streak">0</b><span>يوم متتابع</span></div><div><b>${state.bookmarks.length}</b><span>آية محفوظة</span></div><div><b id="planPct">0%</b><span>ورد اليوم</span></div></div><h2 class="sectionTitle">مواقيت اليوم</h2><div id="homePrayers" class="prayers"><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div></div><h2 class="sectionTitle">رفيق نُور 🎯</h2><div class="card plan"><div><b>وردك اليومي</b><p class="muted">صلاة • قرآن • أذكار • تسبيح</p></div><button class="action" onclick="dailyPlan()">ابدأ الآن</button></div><h2 class="sectionTitle">استكشف</h2><div class="grid"><div class="card" onclick="nav('quran')"><div class="emoji">📖</div><b>القرآن الكريم</b><span class="muted">114 سورة • استماع وحفظ</span></div><div class="card" onclick="nav('azkar')"><div class="emoji">🤲</div><b>الأذكار</b><span class="muted">أكثر من 20 قسمًا من الأذكار</span></div><div class="card" onclick="nav('prayer')"><div class="emoji">🕌</div><b>الصلاة والأذان</b><span class="muted">مواقيت • قبلة • تنبيهات</span></div><div class="card" onclick="tasbeeh()"><div class="emoji">📿</div><b>السبحة</b><span class="muted">عداد ومجموع يومي</span></div><div class="card" onclick="khatma()"><div class="emoji">🎯</div><b>ختمة القرآن</b><span class="muted">خطة تناسبك</span></div><div class="card" onclick="session()"><div class="emoji">🎧</div><b>جلسة استماع</b><span class="muted">اختر قارئك</span></div></div><h2 class="sectionTitle">آية اليوم ✨</h2><div id="ayahDay" class="card ayah">جاري التحميل...</div>`}
function quran(){return `<div class="titleRow"><div><h1>القرآن الكريم 📖</h1><span class="muted">اقرأ • استمع • احفظ • تدبر</span></div><button class="iconBtn" onclick="showReciters()">🎧</button></div><div class="featureRow"><button class="action" onclick="showReciters()">🎧 القراء</button><button class="action" onclick="savedAyah()">⭐ المحفوظات (${state.bookmarks.length})</button><button class="action" onclick="khatma()">🎯 الختمة</button></div><input id="surahSearch" class="search" placeholder="ابحث عن سورة..." oninput="filterSurahs(this.value)"><div id="surahList" class="list" style="margin-top:12px"></div>`}
let azkarTab='sabah';
const AZKAR_TAB_LABELS={sabah:'أذكار الصباح',masaa:'أذكار المساء',aam:'أذكار عامة'};
function azkarPage(){const items=adhkar.map((z,i)=>({z,i})).filter(x=>x.z[3]===azkarTab);return `<h1>الأذكار والدعاء 🤲</h1><div class="quote">«ألا بذكر الله تطمئن القلوب»</div><div class="card plan"><div><b>ورد اليوم</b><p class="muted">أكمل أذكارك وسجّل تقدمك على جهازك.</p></div><button class="action" onclick="dailyPlan()">ورد نُور</button></div><div class="chips azkarTabs">${Object.keys(AZKAR_TAB_LABELS).map(k=>`<span class="${azkarTab===k?'active':''}" onclick="setAzkarTab('${k}')">${AZKAR_TAB_LABELS[k]}</span>`).join('')}</div><h2 class="sectionTitle">${AZKAR_TAB_LABELS[azkarTab]}</h2><div class="list">${items.map(({z,i})=>`<div class="dhikr"><div class="dhikrHead"><b>${z[0]}</b><span class="badge">${z[2]} مرة</span></div><p>${z[1]}</p><button class="bigBtn" onclick="openDhikr(${i})">ابدأ الذكر</button></div>`).join('')||'<div class="empty">لا توجد أذكار في هذا القسم.</div>'}</div>`}
function setAzkarTab(k){azkarTab=k;nav('azkar')}
function prayerPage(){return `<h1>الصلاة والأذان 🕌</h1><div class="card"><div class="settingsLine"><b>الموقع</b><span id="locationLabel" class="muted">لم يتم تحديد الموقع</span></div><button class="bigBtn" onclick="requestLocation()">📍 السماح بالموقع وتحديده تلقائيًا</button><p class="muted">أو ابحث عن مدينتك يدويًا إذا فضّلت عدم مشاركة موقعك:</p><div class="citySearchRow"><input id="cityInput" class="search" placeholder="اكتب اسم مدينتك، مثال: القاهرة" onkeydown="if(event.key==='Enter')searchCity()"><button class="action" onclick="searchCity()">بحث</button></div><div id="citySearchResults"></div></div><div class="card"><div class="settingsLine"><b>الأذان</b><label class="switch"><input id="adhanToggle" type="checkbox" ${state.adhan?'checked':''} onchange="state.adhan=this.checked;save(); if(window.AndroidNoor){if(this.checked) enableNativeAdhan(); else AndroidNoor.disableAdhan()}"><span></span></label></div><p class="muted">في نسخة APK: أذان حقيقي في وقت الصلاة حتى مع إغلاق التطبيق، مع إشعار Android. يتم تفعيله تلقائيًا أول ما تفتح التطبيق ويطلب منك السماح بالإشعارات والمنبهات الدقيقة.</p><select class="search" onchange="state.adhanVoice=this.value;save();scheduleTodayAdhan()">${adhans.map(x=>`<option value="${x[1]}" ${state.adhanVoice===x[1]?'selected':''}>${x[0]}</option>`).join('')}</select><button class="bigBtn" onclick="enableNativeAdhan()">🔔 تفعيل أذان الهاتف</button><button class="action" onclick="testAdhan('تجربة')">▶️ تجربة الأذان الآن</button></div><div class="card"><div class="settingsLine"><b>طريقة الحساب</b><select class="miniSelect" onchange="state.method=this.value;save();loadPrayer('prayerList')"><option value="5" ${state.method==5?'selected':''}>مصر (الهيئة المصرية)</option><option value="4" ${state.method==4?'selected':''}>أم القرى</option><option value="3" ${state.method==3?'selected':''}>رابطة العالم الإسلامي</option></select></div></div><h2 class="sectionTitle">مواقيت اليوم</h2><div id="prayerList" class="list"><div class="muted">جاري التحميل...</div></div><h2 class="sectionTitle">القبلة 🧭</h2><div class="card qiblaCard"><div id="qiblaArrow" class="qiblaArrow">🧭</div><p id="qiblaText">اضغط لتحديد اتجاه القبلة</p><button class="bigBtn" onclick="qibla()">تحديد اتجاه القبلة</button></div>`}
async function searchCity(){
  const box=document.getElementById('citySearchResults'); const input=document.getElementById('cityInput');
  const q=(input?.value||'').trim(); if(!q){toast('اكتب اسم مدينة أولًا');return}
  box.innerHTML='<div class="muted">جارِ البحث...</div>';
  try{
    const r=await fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&q=${encodeURIComponent(q)}&limit=5&addressdetails=1`,{headers:{'Accept':'application/json'}});
    const list=await r.json();
    if(!list.length){box.innerHTML='<div class="empty">لم يتم العثور على هذه المدينة، جرّب اسمًا آخر.</div>';return}
    box.innerHTML=list.map((p,i)=>`<div class="cityResult" onclick="pickCity(${p.lat},${p.lon},'${(p.display_name||'').replace(/'/g,"\\'")}')">📍 ${p.display_name}</div>`).join('');
  }catch(e){box.innerHTML='<div class="empty">تعذر البحث الآن، تحقق من الإنترنت.</div>'}
}
function pickCity(lat,lon,name){
  coords={lat:Number(lat),lon:Number(lon)}; state.location=coords; save();
  document.getElementById('citySearchResults').innerHTML='';
  document.getElementById('cityInput').value='';
  toast('تم تحديد موقعك: '+name);
  loadPrayer('prayerList'); refreshPrayerLocationUI();
  if(current==='home') homeAfter();
}
function more(){return `<h1>المزيد ✨</h1><div class="grid"><div class="card" onclick="khatma()"><div class="emoji">📚</div><b>ختمة القرآن</b><span class="muted">خطة 7 / 15 / 30 يوم</span></div><div class="card" onclick="hijriCalendar()"><div class="emoji">🌙</div><b>التقويم الهجري</b><span class="muted">التاريخ والمناسبات</span></div><div class="card" onclick="ramadan()"><div class="emoji">🌙</div><b>رمضان</b><span class="muted">الإمساك والإفطار</span></div><div class="card" onclick="hajj()"><div class="emoji">🕋</div><b>الحج والعمرة</b><span class="muted">دليل المناسك</span></div><div class="card" onclick="names()"><div class="emoji">✨</div><b>أسماء الله الحسنى</b><span class="muted">99 اسمًا</span></div><div class="card" onclick="showReciters()"><div class="emoji">🎧</div><b>القراء</b><span class="muted">${reciters.length} أصوات</span></div><div class="card" onclick="booksPage()"><div class="emoji">📚</div><b>مكتبة نُور</b><span class="muted">سيرة • حديث • تفسير • فقه • تزكية</span></div><div class="card" onclick="tasbeeh()"><div class="emoji">📿</div><b>السبحة</b><span class="muted">ذكر وعداد</span></div><div class="card" onclick="settings()"><div class="emoji">⚙️</div><b>الإعدادات</b><span class="muted">المظهر والتنبيهات</span></div></div><div class="card about"><b>نُور — رفيق العبادة</b><p class="muted">تطبيق عربي شامل للقرآن والصلاة والأذكار والقبلة والورد اليومي، مصمم ليكون سريعًا وبسيطًا وهادئًا.</p><div class="chips"><span>قرآن</span><span>أذان</span><span>أذكار</span><span>قبلة</span><span>ختمة</span></div></div>`}
async function init(){document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>nav(b.dataset.page)); document.getElementById('themeBtn').onclick=toggleTheme; if(localStorage.dark==='true')document.body.classList.add('dark'); render(); await updateHijri(); requestStartupPermissions();}
function requestStartupPermissions(){
  if(!window.AndroidNoor) return; // الطلب التلقائي فقط داخل تطبيق الأندرويد الأصلي، أما على المتصفح فيبقى الطلب عند الحاجة فقط
  setTimeout(async ()=>{
    try{ await requestLocation(); }catch(e){}
    setTimeout(()=>{ try{ enableNativeAdhan(); }catch(e){} }, 1200);
  }, 900);
}
async function homeAfter(){loadPrayer('homePrayers'); randomAyah(); updateStats();}
let __locationRequestPromise=null;
function requestLocation(){
  if(__locationRequestPromise)return __locationRequestPromise;
  __locationRequestPromise=requestLocationInner().finally(()=>{__locationRequestPromise=null});
  return __locationRequestPromise;
}
async function requestLocationInner(){
  if(window.AndroidNoor && typeof AndroidNoor.requestLocation==='function'){
    toast('اسمح للموقع من نافذة Android 📍');
    return await new Promise((resolve)=>{
      let done=false;
      const finish=(value)=>{if(done)return;done=true;window.__nativeLocation=null;window.__nativeLocationError=null;resolve(value)};
      window.__nativeLocation=(lat,lon,accuracy)=>{
        coords={lat:Number(lat),lon:Number(lon),accuracy:Number(accuracy)||null};
        state.location=coords; save();
        // لا ننتظر تحويل الإحداثيات لاسم مدينة قبل تحميل المواقيت.
        if(current==='prayer') loadPrayer('prayerList'); else if(current==='home') homeAfter();
        refreshPrayerLocationUI();
        autoSelectMethod(coords.lat,coords.lon).then(()=>{
          // إعادة تحميل المواقيت فقط إذا تغيّرت طريقة الحساب بسبب الدولة.
          if(current==='prayer') loadPrayer('prayerList'); else if(current==='home') loadPrayer('homePrayers');
        }).catch(()=>{});
        toast(`تم تحديد موقعك${coords.accuracy?` بدقة ${Math.round(coords.accuracy)}م`:''} 📍`);
        finish(coords);
      };
      window.__nativeLocationError=(code)=>{
        if(code==='permission') toast('اسمح للموقع من إعدادات الهاتف ثم اضغط تحديد موقعي مرة أخرى 📍');
        else if(code==='timeout') toast('تعذر الحصول على GPS. فعّل الموقع وحاول مرة أخرى.');
        else toast('تعذر تحديد الموقع الآن، حاول مرة أخرى.');
        finish(null);
      };
      AndroidNoor.requestLocation();
      setTimeout(()=>finish(null),23000);
    });
  }
  if(!navigator.geolocation){toast('الموقع غير متاح على هذا الجهاز');return null}
  toast('اسمح للموقع من النافذة التي ستظهر الآن 📍');
  try{
    const p=await new Promise((res,rej)=>navigator.geolocation.getCurrentPosition(res,rej,{enableHighAccuracy:true,timeout:15000,maximumAge:600000}));
    coords={lat:p.coords.latitude,lon:p.coords.longitude,accuracy:p.coords.accuracy}; state.location=coords; save();
    if(current==='prayer') loadPrayer('prayerList'); else if(current==='home') homeAfter();
    refreshPrayerLocationUI();
    autoSelectMethod(coords.lat,coords.lon).then(()=>{if(current==='prayer')loadPrayer('prayerList');else if(current==='home')loadPrayer('homePrayers')}).catch(()=>{});
    toast(`تم تحديد موقعك بدقة ${Math.round(coords.accuracy)}م 📍`);
    return coords;
  }catch(e){toast(e&&e.code===1?'تم رفض إذن الموقع. فعّله من إعدادات الهاتف ثم حاول مرة أخرى.':'تعذر تحديد الموقع الآن، حاول مرة أخرى.');return null}
}
const DEFAULT_LOCATION={lat:30.0444,lon:31.2357,label:'القاهرة (تقريبي)'};
let __defaultLocationWarned=false;
async function getCoords(){
  if(coords)return coords;
  if(state.location && Number.isFinite(state.location.lat) && Number.isFinite(state.location.lon)){coords=state.location;return coords;}
  const got=await requestLocation();
  if(got)return got;
  if(!__defaultLocationWarned){__defaultLocationWarned=true;toast('تعذر تحديد موقعك — تُعرض مواقيت تقريبية لمدينة القاهرة، اضغط 📍 لتحديد موقعك الفعلي');}
  return {...DEFAULT_LOCATION,isDefault:true};
}
async function autoSelectMethod(lat,lon){
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),3500);
  try{
    const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&zoom=3&addressdetails=1`,{headers:{'Accept':'application/json'},signal:controller.signal});
    if(!r.ok)return; const j=await r.json(); const cc=(j.address?.country_code||'').toLowerCase();
    const map={eg:5,sa:4,ae:16,kw:9,qa:10,tr:13,id:20,my:17,ma:21,dz:19,tn:18,pk:1};
    if(map[cc] && state.method!==map[cc]){state.method=map[cc];save();}
  }catch(e){} finally{clearTimeout(timer)}
}
async function refreshPrayerLocationUI(){
  if(!coords)return;
  const label=document.getElementById('locationLabel'),place=document.getElementById('place');
  if(coords && coords.isDefault){
    if(label)label.textContent='موقع افتراضي (القاهرة) — اضغط لتحديد موقعك الفعلي 📍';
    if(place)place.textContent='📍 تحديد موقعي (الوضع الحالي تقريبي)';
    return;
  }
  let text='تم تحديد موقعك الحالي 📍';
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),3500);
  try{
    const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(coords.lat)}&lon=${encodeURIComponent(coords.lon)}&zoom=10&addressdetails=1`,{headers:{'Accept':'application/json'},signal:controller.signal});
    if(r.ok){const j=await r.json(),a=j.address||{},city=a.city||a.town||a.village||a.county||a.state,country=a.country;if(city)text=`${city}${country?'، '+country:''}`;}
  }catch(e){} finally{clearTimeout(timer)}
  if(label)label.textContent=text;
  if(place)place.textContent='📍 '+text;
}
async function loadPrayer(target){
 const el=document.getElementById(target);
 const renderTimes=(timings)=>{prayersData=timings;const html=prayers.map(p=>`<div class="pray"><span>${p[2]}</span><b>${p[0]}</b><strong>${format12(timings[p[1]]||'--')}</strong></div>`).join('');if(el)el.innerHTML=target==='homePrayers'?html:prayers.map(p=>`<div class="card prayerRow"><span class="prayIcon">${p[2]}</span><div><b>${p[0]}</b><span class="muted">${p[1]}</span></div><strong>${format12(timings[p[1]]||'--')}</strong>${p[1]!=='Sunrise'?`<button class="action" onclick="testAdhan('${p[0]}')">🔊</button>`:''}</div>`).join('');if(target==='homePrayers')setNextPrayer();scheduleTodayAdhan();};
 try{const {lat,lon}=await getCoords();const d=new Date();const date=String(d.getDate()).padStart(2,'0')+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+d.getFullYear();const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),9000);const r=await fetch(`${A}/timings/${date}?latitude=${lat}&longitude=${lon}&method=${state.method}`,{signal:controller.signal});clearTimeout(timer);if(!r.ok)throw new Error('HTTP');const j=await r.json();if(!j?.data?.timings)throw new Error('DATA');localStorage.noorPrayerCache=JSON.stringify({date,timings:j.data.timings,lat,lon,method:state.method});renderTimes(j.data.timings);refreshPrayerLocationUI();}catch(e){try{const c=JSON.parse(localStorage.noorPrayerCache||'null');if(c?.timings){renderTimes(c.timings);toast('تم استخدام آخر مواقيت محفوظة مؤقتًا');return;}}catch(_){}clearInterval(window.noorTick);const n=document.getElementById('nextName'),tm=document.getElementById('nextTime'),cd=document.getElementById('countdown');if(n)n.textContent='غير متاح';if(tm)tm.textContent='--:--';if(cd)cd.textContent='تحقق من الإنترنت';if(el)el.innerHTML='<div class="card">تعذر تحميل المواقيت الآن. تحقق من الإنترنت ثم حاول مرة أخرى.</div>';}}
function parsePrayerTime(raw){const m=String(raw||'').match(/(\d{1,2}):(\d{2})/);return m?{h:+m[1],m:+m[2]}:null}
function format12(raw){const t=parsePrayerTime(raw);if(!t)return '--:--';const ap=t.h>=12?'م':'ص';let h=t.h%12;if(h===0)h=12;return `${String(h).padStart(2,'0')}:${String(t.m).padStart(2,'0')} ${ap}`}
function setNextPrayer(){if(!prayersData)return;const now=new Date();let best=null;for(const [ar,key] of prayers){const t=parsePrayerTime(prayersData[key]);if(!t)continue;const dt=new Date(now);dt.setHours(t.h,t.m,0,0);if(dt>now&&(!best||dt<best.dt))best={ar,raw:prayersData[key],dt};}if(!best){const t=parsePrayerTime(prayersData.Fajr);if(t)best={ar:'الفجر',raw:prayersData.Fajr,dt:new Date(now.getFullYear(),now.getMonth(),now.getDate()+1,t.h,t.m)}}if(!best)return;const n=document.getElementById('nextName'),tm=document.getElementById('nextTime');if(n)n.textContent=best.ar;if(tm)tm.textContent=format12(best.raw);const tick=()=>{const diff=Math.max(0,best.dt-new Date());const hh=Math.floor(diff/36e5),mm=Math.floor(diff%36e5/6e4),ss=Math.floor(diff%6e4/1e3);const c=document.getElementById('countdown');if(c)c.textContent=`متبقي ${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`};tick();clearInterval(window.noorTick);window.noorTick=setInterval(tick,1000)}
async function fetchHijri(){const d=new Date();const r=await fetch(`${A}/gToH?date=${String(d.getDate()).padStart(2,'0')}-${String(d.getMonth()+1).padStart(2,'0')}-${d.getFullYear()}`);const j=await r.json();return j.data;}
async function updateHijri(){try{const data=await fetchHijri();document.getElementById('hijri').textContent=`${data.hijri.day} ${data.hijri.month.ar} ${data.hijri.year} هـ`; }catch(e){document.getElementById('hijri').textContent='التقويم الهجري';}}
async function randomAyah(){try{const r=await fetch(`${Q}/ayah/random/quran-uthmani`),j=await r.json(),a=j.data;document.getElementById('ayahDay').innerHTML=`<div class="ayahText">${a.text}</div><small>${a.surah.name} • الآية ${a.numberInSurah}</small><div class="ayahActions"><button class="action" onclick="playAyah(${a.number})">▶️ استماع</button><button class="action" onclick="bookmark(${a.number},${JSON.stringify(a.text).replace(/"/g,'&quot;')},${a.surah.number},${a.numberInSurah})">⭐ حفظ</button></div>`;}catch(e){document.getElementById('ayahDay').textContent='بسم الله الرحمن الرحيم';}}
function filterSurahs(q){const el=document.getElementById('surahList');if(!el)return;const a=surahs.map((s,i)=>({s,i})).filter(x=>x.s.includes(q.trim()));el.innerHTML=a.map(x=>`<div class="surah" onclick="openSurah(${x.i+1})"><div class="num">${x.i+1}</div><div class="surahName"><b>سورة ${x.s}</b><span class="muted">قراءة • استماع • حفظ</span></div><span>‹</span></div>`).join('')||'<div class="card">لا توجد سورة بهذا الاسم.</div>'}
async function openSurah(n){view.innerHTML='<div class="loader">جاري تحميل السورة…</div>';try{const r=await fetch(`${Q}/surah/${n}/quran-uthmani`),j=await r.json(),s=j.data;currentSurah=n;view.innerHTML=`<div class="surahHeader"><button class="action" onclick="nav('quran')">‹ القرآن</button><div><h1>سورة ${s.name}</h1><span>${s.numberOfAyahs} آية • ${s.revelationType==='Meccan'?'مكية':'مدنية'}</span></div><button class="action" onclick="playSurah(${n})">▶️</button></div><div class="bismillah">بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ</div><div id="ayahList">${s.ayahs.map(a=>`<article class="ayah"><div class="ayahText">${a.text} <span class="ayahNo">${a.numberInSurah}</span></div><div class="ayahActions"><button class="action" onclick="playAyah(${a.number})">▶️</button><button class="action" onclick="bookmark(${a.number},${JSON.stringify(a.text).replace(/"/g,'&quot;')},${n},${a.numberInSurah})">⭐</button><button class="action" onclick="shareText(${JSON.stringify(a.text).replace(/"/g,'&quot;')})">↗️</button></div></article>`).join('')}</div>`;}catch(e){view.innerHTML='<div class="card">تعذر تحميل السورة.</div>';}}
const AYAH_AUDIO_EDITION='ar.alafasy';
function audioUrl(ayah){return `${CDN}/quran/audio/128/${AYAH_AUDIO_EDITION}/${ayah}.mp3`}
function playAyah(n){if(audio)audio.pause();audio=new Audio(audioUrl(n));audio.play().catch(()=>toast('اضغط تشغيل مرة أخرى للسماح بالصوت'));playerMini('تشغيل الآية (صوت موحّد)',audio)}
function playSurah(n){if(audio)audio.pause();const r=reciters.find(x=>x[1]===state.reciter)||reciters[0];const url=r[1]+String(n).padStart(3,'0')+'.mp3';audio=new Audio(url);audio.play().catch(()=>toast('تعذر تشغيل الصوت، جرّب قارئًا آخر من صفحة القراء'));playerMini(`سورة ${surahs[n-1]}`,audio)}
function playerMini(name,a){let p=document.getElementById('playerMini');if(!p){p=document.createElement('div');p.id='playerMini';document.body.appendChild(p)}p.innerHTML=`<div><b>🎧 ${name}</b><span>${reciters.find(x=>x[1]===state.reciter)?.[0]||'القارئ'}</span></div><button onclick="audio.pause();this.parentElement.remove()">×</button>`;a.onended=()=>p.remove()}
function showReciters(){view.innerHTML=`<h1>القراء 🎧</h1><p class="muted">اختر قارئك الافتراضي، وسيستخدمه نُور في الاستماع للقرآن.</p><div class="list">${reciters.map(r=>`<div class="card reciter ${state.reciter===r[1]?'selected':''}" onclick="chooseReciter('${r[1]}')"><div><b>${r[0]}</b><span class="muted">رواية حفص عن عاصم</span></div><span>${state.reciter===r[1]?'✓':'›'}</span></div>`).join('')}</div>`}
function chooseReciter(id){state.reciter=id;save();toast('تم اختيار القارئ');showReciters()}
function bookmark(number,text,surah,ayah){if(state.bookmarks.some(x=>x.number===number)){state.bookmarks=state.bookmarks.filter(x=>x.number!==number);toast('أزيلت من المحفوظات')}else{state.bookmarks.push({number,text,surah,ayah});toast('تم حفظ الآية ⭐')}save();}
function savedAyah(){view.innerHTML=`<h1>المحفوظات ⭐</h1>${state.bookmarks.length?`<div class="list">${state.bookmarks.map(a=>`<article class="card ayah"><div class="ayahText">${a.text}</div><small>سورة ${surahs[a.surah-1]} • الآية ${a.ayah}</small><div><button class="action" onclick="playAyah(${a.number})">▶️ استماع</button><button class="action" onclick="bookmark(${a.number},${JSON.stringify(a.text).replace(/"/g,'&quot;')},${a.surah},${a.ayah});savedAyah()">حذف</button></div></article>`).join('')}</div>`:'<div class="empty">لا توجد آيات محفوظة بعد ⭐</div>'}`}
function shareText(t){if(navigator.share)navigator.share({text:t});else{navigator.clipboard?.writeText(t);toast('تم نسخ الآية')}}
function openDhikr(i){const z=adhkar[i],key='dhikr'+i;let count=state.progress[key]||0;view.innerHTML=`<div class="surahHeader"><button class="action" onclick="nav('azkar')">‹ الأذكار</button><h1>${z[0]}</h1><span></span></div><div class="dhikrFocus"><p>${z[1]}</p><div class="counter" id="dhCount">${count}</div><div class="progress"><span id="dhBar" style="width:${Math.min(100,count/z[2]*100)}%"></span></div><button class="tasbeehBtn" onclick="dhTap(${i})">اضغط للذكر</button><button class="action" onclick="state.progress['${key}']=0;save();openDhikr(${i})">إعادة</button></div>`}
function dhTap(i){const key='dhikr'+i;state.progress[key]=(state.progress[key]||0)+1;save();const c=document.getElementById('dhCount'),b=document.getElementById('dhBar');if(c)c.textContent=state.progress[key];if(b)b.style.width=Math.min(100,state.progress[key]/adhkar[i][2]*100)+'%';if(navigator.vibrate)navigator.vibrate(15);if(state.progress[key]>=adhkar[i][2])toast('ما شاء الله، اكتمل الذكر 🤍')}
function tasbeeh(){view.innerHTML=`<h1>السبحة 📿</h1><div class="dhikrFocus"><span class="muted">سبحان الله • الحمد لله • الله أكبر</span><div class="counter" id="tasCount">${state.tas||0}</div><div class="progress"><span style="width:${Math.min(100,(state.tas||0)%100)}%"></span></div><button class="tasbeehBtn" onclick="tapTas()">📿 تسبيح</button><div><button class="action" onclick="state.tas=0;save();tasbeeh()">تصفير</button><button class="action" onclick="state.tas=(state.tas||0)+33;save();tasbeeh()">+33</button></div></div>`}
function tapTas(){state.tas=(state.tas||0)+1;save();const c=document.getElementById('tasCount');if(c)c.textContent=state.tas;if(navigator.vibrate)navigator.vibrate(12)}
const DAILY_TASKS=[['الصلاة','🕌','حافظ على الصلوات في وقتها'],['القرآن','📖','اقرأ وردك اليومي'],['أذكار الصباح','🌅','أتمم أذكار الصباح'],['أذكار المساء','🌙','أتمم أذكار المساء'],['التسبيح','📿','100 تسبيحة']];
function dailyPlan(){const tasks=DAILY_TASKS;const today=new Date().toISOString().slice(0,10);if(state.plan.date!==today)state.plan={date:today,done:{}};save();view.innerHTML=`<h1>رفيق نُور 🎯</h1><div class="card"><b>خطة اليوم</b><p class="muted">خطوات صغيرة ثابتة أفضل من الكثير المنقطع.</p><div class="progress"><span id="planBar" style="width:${planPercent(tasks)}%"></span></div></div><div class="list">${tasks.map((t,i)=>`<div class="card task ${state.plan.done[i]?'done':''}" onclick="toggleTask(${i})"><span class="taskIcon">${t[1]}</span><div><b>${t[0]}</b><span class="muted">${t[2]}</span></div><span class="check">${state.plan.done[i]?'✓':'○'}</span></div>`).join('')}</div>`}
function planPercent(tasks){const today=new Date().toISOString().slice(0,10);const done=state.plan.date===today?(state.plan.done||{}):{};return Math.round(Object.keys(done).length/tasks.length*100)}
function toggleTask(i){const today=new Date().toISOString().slice(0,10);if(state.plan.date!==today)state.plan={date:today,done:{}};state.plan.done[i]=!state.plan.done[i];save();dailyPlan()}
function updateStats(){const pct=planPercent(DAILY_TASKS);const e=document.getElementById('planPct');if(e)e.textContent=pct+'%';const st=document.getElementById('streak');if(st)st.textContent=state.streak||0}
function khatma(){view.innerHTML=`<h1>ختمة القرآن 📚</h1><div class="card"><b>اختر مدة الختمة</b><p class="muted">يحسب لك نُور عدد الصفحات اليومية.</p><div class="grid"><button class="card option" onclick="startKhatma(7)">7 أيام<br><b>86 صفحة/يوم</b></button><button class="card option" onclick="startKhatma(15)">15 يومًا<br><b>40 صفحة/يوم</b></button><button class="card option" onclick="startKhatma(30)">30 يومًا<br><b>20 صفحة/يوم</b></button><button class="card option" onclick="startKhatma(60)">60 يومًا<br><b>10 صفحات/يوم</b></button></div></div>${state.khatma?`<div class="card"><b>ختمتك الحالية: ${state.khatma.days} يوم</b><div class="progress"><span style="width:${state.khatma.page/604*100}%"></span></div><p class="muted">صفحة ${state.khatma.page} من 604</p><button class="bigBtn" onclick="advanceKhatma()">أنجزت ورد اليوم</button></div>`:''}`}
function startKhatma(days){state.khatma={days,page:0};save();khatma();toast('بدأت ختمتك 🤍')}
function advanceKhatma(){state.khatma.page=Math.min(604,state.khatma.page+Math.ceil(604/state.khatma.days));save();khatma();if(state.khatma.page>=604)toast('مبارك! أتممت الختمة 🎉')}
function session(){showReciters()}
function hijriCalendar(){view.innerHTML=`<h1>التقويم الهجري 🌙</h1><div class="card"><div id="calendarBox">جاري تحميل التاريخ...</div></div><div class="grid"><div class="card"><b>الجمعة</b><span class="muted">سورة الكهف • الصلاة على النبي ﷺ</span></div><div class="card"><b>الأيام البيض</b><span class="muted">13 • 14 • 15 من الشهر الهجري</span></div></div>`;updateHijriBox()}
async function updateHijriBox(){try{const data=await fetchHijri();const h=data.hijri;document.getElementById('calendarBox').innerHTML=`<div class="bigDate">${h.day}</div><h2>${h.month.ar}</h2><p>${h.year} هـ • ${data.gregorian.date}</p>`}catch(e){document.getElementById('calendarBox').innerHTML='<div class="empty">تعذر تحميل التاريخ الهجري.</div>';}}
function ramadan(){view.innerHTML=`<h1>رمضان 🌙</h1><div class="hero miniHero"><h2>رمضان شهر القرآن</h2><p>خطط لوردك، وتابع الصيام والقيام والصدقة.</p></div><div class="grid"><div class="card"><div class="emoji">🌅</div><b>الإمساك</b><span class="muted">وقت الفجر</span></div><div class="card"><div class="emoji">🌇</div><b>الإفطار</b><span class="muted">وقت المغرب</span></div><div class="card"><div class="emoji">📖</div><b>ورد القرآن</b><span class="muted">جزء يومي</span></div><div class="card"><div class="emoji">🤲</div><b>دعاء</b><span class="muted">أدعية مأثورة</span></div></div><button class="bigBtn" onclick="khatma()">ابدأ ختمة رمضان</button>`}
function hajj(){view.innerHTML=`<h1>الحج والعمرة 🕋</h1><p class="muted">دليل مختصر للمراجعة، وللتفاصيل الفقهية يرجع لأهل العلم والجهات الرسمية.</p><div class="list">${[['الإحرام','النية والتلبية وترك محظورات الإحرام.'],['الطواف','سبعة أشواط حول الكعبة.'],['السعي','بين الصفا والمروة سبعة أشواط.'],['عرفة ومزدلفة ومنى','من أعظم مناسك الحج وأيامه.'],['التحلل','الحلق أو التقصير وفق النسك.']].map(x=>`<div class="card"><b>${x[0]}</b><p class="muted">${x[1]}</p></div>`).join('')}</div>`}
function booksPage(){view.innerHTML=`<div class="titleRow"><div><h1>مكتبة نُور 📚</h1><span class="muted">كتب السيرة والحديث والتفسير والفقه والتزكية</span></div><span class="badge">${books.length} كتابًا</span></div><input id="bookSearch" class="search" placeholder="ابحث عن كتاب أو مؤلف أو قسم..." oninput="filterBooks(this.value)"><div class="chips"><span>السيرة</span><span>الحديث</span><span>التفسير</span><span>الفقه</span><span>الأذكار</span><span>التزكية</span></div><div id="bookList" class="list" style="margin-top:12px"></div>`;filterBooks('')}
function filterBooks(q){const el=document.getElementById('bookList');if(!el)return;const term=(q||'').trim().toLowerCase();const list=books.filter(b=>b.join(' ').toLowerCase().includes(term));el.innerHTML=list.map((b,i)=>`<article class="card bookCard"><div class="bookTop"><div class="bookCover">📖</div><div><b>${b[0]}</b><span class="muted">${b[1]} • ${b[2]}</span></div></div><p class="muted bookDesc">${b[3]}</p><button class="action" onclick="bookInfo(${books.indexOf(b)})">نبذة عن الكتاب</button></article>`).join('')||'<div class="empty">لا توجد كتب مطابقة للبحث.</div>'}
function bookInfo(i){const b=books[i];view.innerHTML=`<div class="surahHeader"><button class="action" onclick="booksPage()">‹ المكتبة</button><h1>📚</h1><span></span></div><div class="card bookDetails"><div class="bookCover big">📖</div><h2>${b[0]}</h2><p class="muted">المؤلف: ${b[1]}</p><p class="muted">التصنيف: ${b[2]}</p><p class="bookLong">${b[3]}</p><div class="quote">يمكن إضافة نصوص الكتب المرخصة أو روابط مصادر القراءة الموثوقة لاحقًا، مع الحفاظ على حقوق النشر.</div><button class="bigBtn" onclick="booksPage()">العودة إلى المكتبة</button></div>`}
function names(){view.innerHTML=`<h1>أسماء الله الحسنى ✨</h1><div class="grid">${namesAllah.map((x,i)=>`<div class="card nameCard"><span>${String(i+1).padStart(2,'0')}</span><b>${x}</b></div>`).join('')}</div>`}
function settings(){view.innerHTML=`<h1>الإعدادات ⚙️</h1><div class="list"><div class="card settingsLine"><b>الوضع الليلي</b><button class="action" onclick="toggleTheme()">تبديل</button></div><div class="card settingsLine"><b>القارئ الافتراضي</b><button class="action" onclick="showReciters()">${reciters.find(x=>x[1]===state.reciter)?.[0]||'اختيار'}</button></div><div class="card settingsLine"><b>الأذان</b><button class="action" onclick="nav('prayer')">الإعدادات</button></div><div class="card"><b>الخصوصية</b><p class="muted">بيانات التقدم والمحفوظات تُحفظ محليًا على جهازك في هذه النسخة.</p></div></div>`}
function toggleTheme(){document.body.classList.toggle('dark');localStorage.dark=document.body.classList.contains('dark')}
function locate(){coords=null;getCoords().then(()=>{toast('تم تحديد موقعك 📍');nav('prayer')})}
async function qibla(){
  try{
    let c = (coords && !coords.isDefault) ? coords : ((state.location && Number.isFinite(state.location.lat) && Number.isFinite(state.location.lon)) ? state.location : null);
    if(!c) c = await requestLocation();
    if(!c){ toast('يجب تحديد موقعك الفعلي أولًا لمعرفة اتجاه القبلة بدقة'); const t=document.getElementById('qiblaText'); if(t)t.textContent='حدد موقعك أولًا لمعرفة اتجاه القبلة بدقة'; return; }
    const r=await fetch(`${A}/qibla/${c.lat}/${c.lon}`),j=await r.json(),d=Math.round(j.data.direction);
    document.getElementById('qiblaText').textContent=`اتجاه القبلة ${d}° من الشمال`;
    document.getElementById('qiblaArrow').style.transform=`rotate(${d}deg)`;
  }catch(e){toast('تعذر تحديد القبلة')}
}
function adhanUrl(){return state.adhanVoice||adhans[0][1]}
function enableNativeAdhan(){state.adhan=true;save();if(window.AndroidNoor){AndroidNoor.enableAdhan();scheduleTodayAdhan();toast('تم تفعيل أذان الهاتف 🔔')}else toast('هذه الميزة تعمل بكاملها داخل APK')}
async function scheduleTodayAdhan(){
  if(!state.adhan||!window.AndroidNoor||!prayersData)return;
  const names=[['الفجر','Fajr'],['الظهر','Dhuhr'],['العصر','Asr'],['المغرب','Maghrib'],['العشاء','Isha']];
  const scheduleDay=(timings,base,idOffset)=>{const baseDate=new Date(base);names.forEach((x,i)=>{const m=parsePrayerTime(timings[x[1]]);if(!m)return;const d=new Date(baseDate);d.setHours(m.h,m.m,0,0);if(d.getTime()>Date.now()+5000)AndroidNoor.schedulePrayer(idOffset+i,x[0],d.getTime(),adhanUrl())})};
  const today=new Date(); scheduleDay(prayersData,today,0);
  try{
    const tomorrow=new Date(today); tomorrow.setDate(today.getDate()+1);
    const dd=String(tomorrow.getDate()).padStart(2,'0')+'-'+String(tomorrow.getMonth()+1).padStart(2,'0')+'-'+tomorrow.getFullYear();
    const {lat,lon}=await getCoords();
    const r=await fetch(`${A}/timings/${dd}?latitude=${lat}&longitude=${lon}&method=${state.method}`); const j=await r.json();
    scheduleDay(j.data.timings,tomorrow,5);
  }catch(e){}
}
function testAdhan(name){if(!state.adhan){toast('الأذان متوقف من الإعدادات');return}if(window.AndroidNoor){AndroidNoor.playNow(name||'الصلاة',adhanUrl());return}const a=new Audio(adhanUrl());a.play().catch(()=>toast('اضغط تشغيل مرة أخرى للسماح بالصوت'));toast(`تجربة أذان ${name||''}`)}
function toast(t){let e=document.getElementById('toast');if(!e){e=document.createElement('div');e.id='toast';document.body.appendChild(e)}e.textContent=t;e.classList.add('show');clearTimeout(window.toastT);window.toastT=setTimeout(()=>e.classList.remove('show'),2500)}
if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{}); window.addEventListener('load',()=>{if(!state.location)setTimeout(()=>requestLocation(),700)}); init();
