# Noor Android Native Adhan

The GitHub build workflow copies these native files into the generated Capacitor Android project.
It adds exact prayer alarms, Android notifications, reboot rescheduling, and background adhan playback.
