package com.ahmedbadr.noor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AdhanReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String prayer = intent.getStringExtra("prayer");
        String url = intent.getStringExtra("url");
        Intent service = new Intent(context, AdhanService.class);
        service.putExtra("prayer", prayer == null ? "الصلاة" : prayer);
        service.putExtra("url", url == null ? "https://cdn.aladhan.com/audio/adhans/a9.mp3" : url);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service);
        else context.startService(service);
    }
}
