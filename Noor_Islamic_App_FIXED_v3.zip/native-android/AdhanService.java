package com.ahmedbadr.noor;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;

public class AdhanService extends Service {
    private MediaPlayer player;
    private static final String CHANNEL = "noor_adhan_playback";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "أذان نُور", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("تشغيل الأذان عند دخول وقت الصلاة");
            c.setSound(null, null);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(c);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String prayer = intent != null ? intent.getStringExtra("prayer") : "الصلاة";
        String url = intent != null ? intent.getStringExtra("url") : null;
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Notification n = b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("حان الآن وقت " + (prayer == null ? "الصلاة" : prayer))
                .setContentText("نُور — الأذان")
                .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) startForeground(1001, n, 2);
        else startForeground(1001, n);

        if (url != null) play(url);
        return START_NOT_STICKY;
    }

    private void play(String url) {
        try {
            if (player != null) { player.release(); player = null; }
            player = new MediaPlayer();
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
            player.setAudioAttributes(attrs);
            player.setDataSource(url);
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(mp -> { mp.release(); stopSelf(); });
            player.setOnErrorListener((mp, what, extra) -> { mp.release(); stopSelf(); return true; });
            player.prepareAsync();
        } catch (Exception e) { stopSelf(); }
    }

    @Override public void onDestroy() {
        if (player != null) { try { player.stop(); } catch(Exception ignored){} player.release(); player=null; }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
