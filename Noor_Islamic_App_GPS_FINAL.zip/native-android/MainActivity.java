package com.ahmedbadr.noor;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private static final int REQ_NOTIF=501;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getBridge().getWebView().addJavascriptInterface(new NoorBridge(this), "AndroidNoor");
    }

    static class NoorBridge {
        final MainActivity a;
        NoorBridge(MainActivity x){a=x;}

        @JavascriptInterface public void enableAdhan(){
            a.getSharedPreferences("noor_adhan",MODE_PRIVATE).edit().putBoolean("enabled",true).apply();
            if(Build.VERSION.SDK_INT>=33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);
            if(Build.VERSION.SDK_INT>=31){
                AlarmManager am=(AlarmManager)a.getSystemService(ALARM_SERVICE);
                if(!am.canScheduleExactAlarms()){
                    try{a.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+a.getPackageName())));}catch(Exception ignored){}
                }
            }
        }
        @JavascriptInterface public void disableAdhan(){
            a.getSharedPreferences("noor_adhan",MODE_PRIVATE).edit().putBoolean("enabled",false).apply();
            AlarmManager am=(AlarmManager)a.getSystemService(ALARM_SERVICE);
            for(int i=0;i<10;i++) cancel(a,am,i);
        }
        @JavascriptInterface public void schedulePrayer(int id,String prayer,long when,String url){
            a.getSharedPreferences("noor_adhan",MODE_PRIVATE).edit().putLong("t"+id,when).putString("p"+id,prayer).putString("u"+id,url).apply();
            BootReceiver.schedule(a,id,when,prayer,url);
        }
        @JavascriptInterface public void playNow(String prayer,String url){
            Intent i=new Intent(a,AdhanService.class).putExtra("prayer",prayer).putExtra("url",url);
            if(Build.VERSION.SDK_INT>=26)a.startForegroundService(i);else a.startService(i);
        }
        static void cancel(Context c,AlarmManager am,int id){
            Intent i=new Intent(c,AdhanReceiver.class);
            PendingIntent pi=PendingIntent.getBroadcast(c,7000+id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);pi.cancel();
        }
    }
}
