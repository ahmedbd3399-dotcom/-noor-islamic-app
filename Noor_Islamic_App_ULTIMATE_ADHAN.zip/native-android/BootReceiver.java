package com.ahmedbadr.noor;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Map;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) &&
            !"android.intent.action.TIME_SET".equals(intent.getAction()) &&
            !"android.intent.action.TIMEZONE_CHANGED".equals(intent.getAction())) return;
        android.content.SharedPreferences p = context.getSharedPreferences("noor_adhan", Context.MODE_PRIVATE);
        if (!p.getBoolean("enabled", false)) return;
        for (int i=0;i<5;i++) {
            long when=p.getLong("t"+i,0);
            String prayer=p.getString("p"+i, "الصلاة");
            String url=p.getString("u"+i, "https://cdn.aladhan.com/audio/adhans/a9.mp3");
            if (when>System.currentTimeMillis()) schedule(context,i,when,prayer,url);
        }
    }
    static void schedule(Context c,int id,long when,String prayer,String url){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent in=new Intent(c,AdhanReceiver.class).putExtra("prayer",prayer).putExtra("url",url);
        PendingIntent pi=PendingIntent.getBroadcast(c, 7000+id, in, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
    }
}
